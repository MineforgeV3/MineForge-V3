Hello, and thank you for downloading MineForge Dupe!
 Here are some key things you need to know about us, any troubleshooting can be found in this very document.	





1 Run the Program as an Administrator

2 Select your Game Installation Folder, (this may vary and can also be found within our games built-in instructions)

3 Wait for it to finish installing the  necessary components into your game installation. This process can take up to 5 minutes depending on your system storage.

4 Once done, type the command "/dupe" (without quotations) 

5 You will then receive the option to duplicate your shulker box by clicing on the "Duplicate" button on the top left of your screen.

6 PLEASE NOTE: You will have to be holding the item in your hand to receive this option.

7 Trusted, Safe & Open Source. Over 250K+ Downloads Certified, Please join our discord for any inquiries or questions regarding this application.

Enjoy!





MineForge Enterprises, 2022©